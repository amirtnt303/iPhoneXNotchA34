# iPhone X Notch for Samsung A34

این پروژه یک overlay مشکی و مات شبیه notch آیفون X ایجاد می‌کند.

ویژگی‌ها:
- Portrait: ناچ بالای صفحه
- Landscape: ناچ به کنار صفحه منتقل می‌شود و ناپدید نمی‌شود
- رنگ کاملاً مشکی
- بدون لمس‌گیری (`NOT_TOUCHABLE`)
- استفاده از `TYPE_APPLICATION_OVERLAY`
- مناسب Android 16 / One UI 8.x

نصب:
1. پروژه را در Android Studio باز کنید.
2. Gradle Sync را انجام دهید.
3. Run را بزنید یا APK بسازید.
4. داخل برنامه مجوز "Display over other apps" را فعال کنید.
5. Overlay را روشن کنید.

توجه: Android ممکن است به دلایل امنیتی/مدیریت منابع روی overlayها محدودیت‌هایی اعمال کند.
