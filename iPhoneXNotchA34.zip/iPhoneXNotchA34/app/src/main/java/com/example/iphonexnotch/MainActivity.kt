package com.example.iphonexnotch

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }

        val title = TextView(this).apply {
            text = "iPhone X Notch"
            textSize = 26f
        }

        val info = TextView(this).apply {
            text = "\nبرای نمایش ناچ، اجازه‌ی «نمایش روی سایر برنامه‌ها» را فعال کن.\n\nناچ در Portrait بالای صفحه و در Landscape کنار صفحه قرار می‌گیرد و هنگام چرخش دوباره تنظیم می‌شود."
            textSize = 16f
        }

        val settings = Button(this).apply {
            text = "فعال‌کردن Overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(
                        Intent(
                            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:$packageName")
                        )
                    )
                } else {
                    startNotch()
                }
            }
        }

        val stop = Button(this).apply {
            text = "خاموش‌کردن ناچ"
            setOnClickListener {
                stopService(Intent(this@MainActivity, NotchService::class.java))
            }
        }

        root.addView(title)
        root.addView(info)
        root.addView(settings)
        root.addView(stop)
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        if (Settings.canDrawOverlays(this)) {
            startNotch()
        }
    }

    private fun startNotch() {
        ContextCompat.startForegroundService(
            this,
            Intent(this, NotchService::class.java)
        )
    }
}
