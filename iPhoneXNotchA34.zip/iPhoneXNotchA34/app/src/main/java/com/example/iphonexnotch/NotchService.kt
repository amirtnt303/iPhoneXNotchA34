package com.example.iphonexnotch

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import kotlin.math.roundToInt

class NotchService : Service() {
    private lateinit var wm: WindowManager
    private var notchView: NotchView? = null
    private var params: WindowManager.LayoutParams? = null

    private val callback = object : ComponentCallbacks2 {
        override fun onConfigurationChanged(newConfig: Configuration) {
            updateNotch()
        }
        override fun onLowMemory() {}
        override fun onTrimMemory(level: Int) {}
    }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(1001, notification())

        if (Settings.canDrawOverlays(this)) {
            wm = getSystemService(WINDOW_SERVICE) as WindowManager
            registerComponentCallbacks(callback)
            addNotch()
        }
    }

    private fun addNotch() {
        notchView?.let { runCatching { wm.removeView(it) } }
        val view = NotchView(this)
        notchView = view

        val portrait = resources.configuration.orientation == Configuration.ORIENTATION_PORTRAIT
        val size = resources.displayMetrics
        val density = size.density

        val notchW = dp(210, density)
        val notchH = dp(36, density)

        val landscape = !portrait
        val width = if (landscape) notchH else notchW
        val height = if (landscape) notchW else notchH

        val gravity = when {
            portrait -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
            resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE -> Gravity.CENTER_VERTICAL or Gravity.START
            else -> Gravity.TOP or Gravity.CENTER_HORIZONTAL
        }

        val p = WindowManager.LayoutParams(
            width,
            height,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )

        p.gravity = gravity
        p.x = 0
        p.y = if (portrait) -1 else 0

        params = p
        wm.addView(view, p)
    }

    private fun updateNotch() {
        notchView?.let {
            runCatching { wm.removeView(it) }
            notchView = null
        }
        addNotch()
    }

    override fun onDestroy() {
        unregisterComponentCallbacks(callback)
        notchView?.let { runCatching { wm.removeView(it) } }
        notchView = null
        super.onDestroy()
    }

    override fun onBind(intent: android.content.Intent?): IBinder? = null

    private fun dp(value: Int, density: Float): Int =
        (value * density).roundToInt()

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(
                "notch",
                "iPhone X Notch",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(channel)
        }
    }

    private fun notification(): Notification {
        return if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "notch")
                .setContentTitle("iPhone X Notch")
                .setContentText("ناچ فعال است")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("iPhone X Notch")
                .setContentText("ناچ فعال است")
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setOngoing(true)
                .build()
        }
    }
}

class NotchView(context: Context) : View(context) {
    private val paint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.BLACK
        style = android.graphics.Paint.Style.FILL
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)

        val w = width.toFloat()
        val h = height.toFloat()

        // iPhone X-style notch: top edge goes beyond the display,
        // with strongly rounded lower corners.
        val r = minOf(w, h) * 0.48f
        val path = android.graphics.Path()

        if (w >= h) {
            path.moveTo(0f, 0f)
            path.lineTo(w, 0f)
            path.lineTo(w, h * 0.42f)
            path.quadTo(w, h, w - r, h)
            path.lineTo(r, h)
            path.quadTo(0f, h, 0f, h * 0.42f)
            path.close()
        } else {
            // Landscape: rotate the same notch shape 90° clockwise.
            canvas.save()
            canvas.rotate(90f, w / 2f, h / 2f)

            val rw = h.toFloat()
            val rh = w.toFloat()
            val rotated = android.graphics.Path()
            rotated.moveTo(0f, 0f)
            rotated.lineTo(rw, 0f)
            rotated.lineTo(rw, rh * 0.42f)
            rotated.quadTo(rw, rh, rw - r, rh)
            rotated.lineTo(r, rh)
            rotated.quadTo(0f, rh, 0f, rh * 0.42f)
            rotated.close()

            val matrix = android.graphics.Matrix()
            matrix.setTranslate((w - rw) / 2f, (h - rh) / 2f)
            rotated.transform(matrix)
            canvas.drawPath(rotated, paint)
            canvas.restore()
            return
        }

        canvas.drawPath(path, paint)
    }
}
